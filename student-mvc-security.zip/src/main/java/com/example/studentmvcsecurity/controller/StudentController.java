package com.example.studentmvcsecurity.controller;

import com.example.studentmvcsecurity.service.StudentService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class StudentController {
    private final StudentService service;

    public StudentController(StudentService service) {
        this.service = service;
    }

    @GetMapping("/")
    public String home() {
        return "redirect:/students";
    }

    @GetMapping("/students")
    public String students(Model model) {
        model.addAttribute("students", service.getAllStudents());
        return "students";
    }
}
