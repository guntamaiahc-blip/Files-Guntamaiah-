package com.example.studentmvcsecurity.service;

import com.example.studentmvcsecurity.model.Student;
import com.example.studentmvcsecurity.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {
    private final StudentRepository repository;

    public StudentService(StudentRepository repository) {
        this.repository = repository;
    }

    public List<Student> getAllStudents() {
        return repository.findAll();
    }
}
