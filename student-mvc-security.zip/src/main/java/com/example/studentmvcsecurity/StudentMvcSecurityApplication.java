package com.example.studentmvcsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentMvcSecurityApplication {
    public static void main(String[] args) {
        SpringApplication.run(StudentMvcSecurityApplication.class, args);
    }
}
