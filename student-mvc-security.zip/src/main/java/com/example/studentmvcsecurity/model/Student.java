package com.example.studentmvcsecurity.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private int marks;

    public Student() {}

    public Student(String name, int marks) {
        this.name = name;
        this.marks = marks;
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public int getMarks() { return marks; }

    public void setId(Long id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setMarks(int marks) { this.marks = marks; }
}
