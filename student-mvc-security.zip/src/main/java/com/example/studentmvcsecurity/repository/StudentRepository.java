package com.example.studentmvcsecurity.repository;

import com.example.studentmvcsecurity.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, Long> {
}
