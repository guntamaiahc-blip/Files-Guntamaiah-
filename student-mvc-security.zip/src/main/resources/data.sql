INSERT INTO student (name, marks) VALUES ('Kanna', 85);
INSERT INTO student (name, marks) VALUES ('Ravi', 90);
INSERT INTO student (name, marks) VALUES ('Sita', 78);
