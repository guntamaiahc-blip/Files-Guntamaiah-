# Student MVC Security Demo

Simple Spring Boot application showing:

- MVC architecture
- URL -> Controller -> Service -> Repository -> Database
- Thymeleaf View
- Spring Security login
- BCrypt password hashing
- H2 database

## Run

Requirements:
- Java 17+
- Maven 3.9+

Run:

    mvn spring-boot:run

Open:

    http://localhost:8080/students

Login:
- Username: kanna
- Password: 12345

This is an educational demo. For production, use stronger credentials, externalized secrets, HTTPS, CSRF-aware forms, and a production database.
